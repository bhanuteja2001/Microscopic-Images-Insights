class resrc:

    GISS_PIC_PATH = 'res\GISS.jpg'
    BABY_JC_PIC_PATH = 'res\BabyJC.jpeg'
    MAD_JC_PIC_PATH = 'res\MadJC.jpeg'